var hi = "hello"; // 전역변수

function greeting(){
    console.log(hi);
}

greeting();